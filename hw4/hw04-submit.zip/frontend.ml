(* 
Use of AI: We used genAI for debugging and finding errors regarding 
the types of of certain values (Ptr Ptr instead of Ptr Struct etc.)
*)

open Ll
open Llutil
open Ast

(* instruction streams ------------------------------------------------------ *)

(* As in the last project, we'll be working with a flattened representation
   of LLVMlite programs to make emitting code easier. This version
   additionally makes it possible to emit elements will be gathered up and
   "hoisted" to specific parts of the constructed CFG
   - G of gid * Ll.gdecl: allows you to output global definitions in the middle
     of the instruction stream. You will find this useful for compiling string
     literals
   - E of uid * insn: allows you to emit an instruction that will be moved up
     to the entry block of the current function. This will be useful for 
     compiling local variable declarations
*)

type elt = 
  | L of Ll.lbl             (* block labels *)
  | I of uid * Ll.insn      (* instruction *)
  | T of Ll.terminator      (* block terminators *)
  | G of gid * Ll.gdecl     (* hoisted globals (usually strings) *)
  | E of uid * Ll.insn      (* hoisted entry block instructions *)

type stream = elt list
let ( >@ ) x y = y @ x
let ( >:: ) x y = y :: x
let lift : (uid * insn) list -> stream = List.rev_map (fun (x,i) -> I (x,i))

(* Build a CFG and collection of global variable definitions from a stream *)
let cfg_of_stream (code:stream) : Ll.cfg * (Ll.gid * Ll.gdecl) list  =
    let gs, einsns, insns, term_opt, blks = List.fold_left
      (fun (gs, einsns, insns, term_opt, blks) e ->
        match e with
        | L l ->
           begin match term_opt with
           | None -> 
              if (List.length insns) = 0 then (gs, einsns, [], None, blks)
              else failwith @@ Printf.sprintf "build_cfg: block labeled %s has\
                                               no terminator" l
           | Some term ->
              (gs, einsns, [], None, (l, {insns; term})::blks)
           end
        | T t  -> (gs, einsns, [], Some (Llutil.Parsing.gensym "tmn", t), blks)
        | I (uid,insn)  -> (gs, einsns, (uid,insn)::insns, term_opt, blks)
        | G (gid,gdecl) ->  ((gid,gdecl)::gs, einsns, insns, term_opt, blks)
        | E (uid,i) -> (gs, (uid, i)::einsns, insns, term_opt, blks)
      ) ([], [], [], None, []) code
    in
    match term_opt with
    | None -> failwith "build_cfg: entry block has no terminator" 
    | Some term -> 
       let insns = einsns @ insns in
       ({insns; term}, blks), gs


(* compilation contexts ----------------------------------------------------- *)

(* To compile OAT variables, we maintain a mapping of source identifiers to the
   corresponding LLVMlite operands. Bindings are added for global OAT variables
   and local variables that are in scope. *)

module Ctxt = struct

  type t = (Ast.id * (Ll.ty * Ll.operand)) list
  let empty = []

  (* Add a binding to the context *)
  let add (c:t) (id:id) (bnd:Ll.ty * Ll.operand) : t = (id,bnd)::c

  (* Lookup a binding in the context *)
  let lookup (id:Ast.id) (c:t) : Ll.ty * Ll.operand =
    List.assoc id c
  
  let lookup_option (id:Ast.id) (c:t) : (Ll.ty * Ll.operand) option =
    try Some (lookup id c ) with _ -> None

  (* Lookup a function, fail otherwise *)
  let lookup_function (id:Ast.id) (c:t) : Ll.ty * Ll.operand =
    match List.assoc id c with
    | Ptr (Fun (args, ret)), g -> Ptr (Fun (args, ret)), g
    | _ -> failwith @@ id ^ " not bound to a function"

  let lookup_function_option (id:Ast.id) (c:t) : (Ll.ty * Ll.operand) option =
    try Some (lookup_function id c) with _ -> None
  
end

(* compiling OAT types ------------------------------------------------------ *)

(* The mapping of source types onto LLVMlite is straightforward. Booleans and ints
   are represented as the corresponding integer types. OAT strings are
   pointers to bytes (I8). Arrays are the most interesting type: they are
   represented as pointers to structs where the first component is the number
   of elements in the following array.

   The trickiest part of this project will be satisfying LLVM's rudimentary type
   system. Recall that global arrays in LLVMlite need to be declared with their
   length in the type to statically allocate the right amount of memory. The 
   global strings and arrays you emit will therefore have a more specific type
   annotation than the output of cmp_rty. You will have to carefully bitcast
   gids to satisfy the LLVM type checker.
*)

let rec cmp_ty : Ast.ty -> Ll.ty = function
  | Ast.TBool  -> I1
  | Ast.TInt   -> I64
  | Ast.TRef r -> Ptr (cmp_rty r)

and cmp_rty : Ast.rty -> Ll.ty = function
  | Ast.RString  -> I8
  | Ast.RArray u -> Struct [I64; Array(0, cmp_ty u)]
  | Ast.RFun (ts, t) -> 
      let args, ret = cmp_fty (ts, t) in
      Fun (args, ret)

and cmp_ret_ty : Ast.ret_ty -> Ll.ty = function
  | Ast.RetVoid  -> Void
  | Ast.RetVal t -> cmp_ty t

and cmp_fty (ts, r) : Ll.fty =
  List.map cmp_ty ts, cmp_ret_ty r


let typ_of_binop : Ast.binop -> Ast.ty * Ast.ty * Ast.ty = function
  | Add | Mul | Sub | Shl | Shr | Sar | IAnd | IOr -> (TInt, TInt, TInt)
  | Eq | Neq | Lt | Lte | Gt | Gte -> (TInt, TInt, TBool)
  | And | Or -> (TBool, TBool, TBool)

let typ_of_unop : Ast.unop -> Ast.ty * Ast.ty = function
  | Neg | Bitnot -> (TInt, TInt)
  | Lognot       -> (TBool, TBool)

(* Compiler Invariants

   The LLVM IR type of a variable (whether global or local) that stores an Oat
   array value (or any other reference type, like "string") will always be a
   double pointer.  In general, any Oat variable of Oat-type t will be
   represented by an LLVM IR value of type Ptr (cmp_ty t).  So the Oat variable
   x : int will be represented by an LLVM IR value of type i64*, y : string will
   be represented by a value of type i8**, and arr : int[] will be represented
   by a value of type {i64, [0 x i64]}**.  Whether the LLVM IR type is a
   "single" or "double" pointer depends on whether t is a reference type.

   We can think of the compiler as paying careful attention to whether a piece
   of Oat syntax denotes the "value" of an expression or a pointer to the
   "storage space associated with it".  This is the distinction between an
   "expression" and the "left-hand-side" of an assignment statement.  Compiling
   an Oat variable identifier as an expression ("value") does the load, so
   cmp_exp called on an Oat variable of type t returns (code that) generates a
   LLVM IR value of type cmp_ty t.  Compiling an identifier as a left-hand-side
   does not do the load, so cmp_lhs called on an Oat variable of type t returns
   and operand of type (cmp_ty t)*.  Extending these invariants to account for
   array accesses: the assignment e1[e2] = e3; treats e1[e2] as a
   left-hand-side, so we compile it as follows: compile e1 as an expression to
   obtain an array value (which is of pointer of type {i64, [0 x s]}* ).
   compile e2 as an expression to obtain an operand of type i64, generate code
   that uses getelementptr to compute the offset from the array value, which is
   a pointer to the "storage space associated with e1[e2]".

   On the other hand, compiling e1[e2] as an expression (to obtain the value of
   the array), we can simply compile e1[e2] as a left-hand-side and then do the
   load.  So cmp_exp and cmp_lhs are mutually recursive.  [[Actually, as I am
   writing this, I think it could make sense to factor the Oat grammar in this
   way, which would make things clearer, I may do that for next time around.]]

 
   Consider globals7.oat

   /--------------- globals7.oat ------------------ 
   global arr = int[] null;

   int foo() { 
     var x = new int[3]; 
     arr = x; 
     x[2] = 3; 
     return arr[2]; 
   }
   /------------------------------------------------

   The translation (given by cmp_ty) of the type int[] is {i64, [0 x i64}* so
   the corresponding LLVM IR declaration will look like:

   @arr = global { i64, [0 x i64] }* null

   This means that the type of the LLVM IR identifier @arr is {i64, [0 x i64]}**
   which is consistent with the type of a locally-declared array variable.

   The local variable x would be allocated and initialized by (something like)
   the following code snippet.  Here %_x7 is the LLVM IR uid containing the
   pointer to the "storage space" for the Oat variable x.

   %_x7 = alloca { i64, [0 x i64] }*                              ;; (1)
   %_raw_array5 = call i64*  @oat_alloc_array(i64 3)              ;; (2)
   %_array6 = bitcast i64* %_raw_array5 to { i64, [0 x i64] }*    ;; (3)
   store { i64, [0 x i64]}* %_array6, { i64, [0 x i64] }** %_x7   ;; (4)

   (1) note that alloca uses cmp_ty (int[]) to find the type, so %_x7 has 
       the same type as @arr 

   (2) @oat_alloc_array allocates len+1 i64's 

   (3) we have to bitcast the result of @oat_alloc_array so we can store it
        in %_x7 

   (4) stores the resulting array value (itself a pointer) into %_x7 

  The assignment arr = x; gets compiled to (something like):

  %_x8 = load { i64, [0 x i64] }*, { i64, [0 x i64] }** %_x7     ;; (5)
  store {i64, [0 x i64] }* %_x8, { i64, [0 x i64] }** @arr       ;; (6)

  (5) load the array value (a pointer) that is stored in the address pointed 
      to by %_x7 

  (6) store the array value (a pointer) into @arr 

  The assignment x[2] = 3; gets compiled to (something like):

  %_x9 = load { i64, [0 x i64] }*, { i64, [0 x i64] }** %_x7      ;; (7)
  %_index_ptr11 = getelementptr { i64, [0 x  i64] }, 
                  { i64, [0 x i64] }* %_x9, i32 0, i32 1, i32 2   ;; (8)
  store i64 3, i64* %_index_ptr11                                 ;; (9)

  (7) as above, load the array value that is stored %_x7 

  (8) calculate the offset from the array using GEP

  (9) store 3 into the array

  Finally, return arr[2]; gets compiled to (something like) the following.
  Note that the way arr is treated is identical to x.  (Once we set up the
  translation, there is no difference between Oat globals and locals, except
  how their storage space is initially allocated.)

  %_arr12 = load { i64, [0 x i64] }*, { i64, [0 x i64] }** @arr    ;; (10)
  %_index_ptr14 = getelementptr { i64, [0 x i64] },                
                 { i64, [0 x i64] }* %_arr12, i32 0, i32 1, i32 2  ;; (11)
  %_index15 = load i64, i64* %_index_ptr14                         ;; (12)
  ret i64 %_index15

  (10) just like for %_x9, load the array value that is stored in @arr 

  (11)  calculate the array index offset

  (12) load the array value at the index 

*)

(* Global initialized arrays:

  There is another wrinkle: To compile global initialized arrays like in the
  globals4.oat, it is helpful to do a bitcast once at the global scope to
  convert the "precise type" required by the LLVM initializer to the actual
  translation type (which sets the array length to 0).  So for globals4.oat,
  the arr global would compile to (something like):

  @arr = global { i64, [0 x i64] }* bitcast 
           ({ i64, [4 x i64] }* @_global_arr5 to { i64, [0 x i64] }* ) 
  @_global_arr5 = global { i64, [4 x i64] } 
                  { i64 4, [4 x i64] [ i64 1, i64 2, i64 3, i64 4 ] }

*) 



(* Some useful helper functions *)

(* Generate a fresh temporary identifier. Since OAT identifiers cannot begin
   with an underscore, these should not clash with any source variables *)
let gensym : string -> string =
  let c = ref 0 in
  fun (s:string) -> incr c; Printf.sprintf "_%s%d" s (!c)

(* Amount of space an Oat type takes when stored in the stack, in bytes.  
   Note that since structured values are manipulated by reference, all
   Oat values take 8 bytes on the stack.
*)
let size_oat_ty (t : Ast.ty) = 8L

(* Generate code to allocate a zero-initialized array of source type TRef (RArray t) of the
   given size. Note "size" is an operand whose value can be computed at
   runtime *)
let oat_alloc_array (t:Ast.ty) (size:Ll.operand) : Ll.ty * operand * stream =
  let ans_id, arr_id = gensym "array", gensym "raw_array" in
  let ans_ty = cmp_ty @@ TRef (RArray t) in
  let arr_ty = Ptr I64 in
  ans_ty, Id ans_id, lift
    [ arr_id, Call(arr_ty, Gid "oat_alloc_array", [I64, size])
    ; ans_id, Bitcast(arr_ty, Id arr_id, ans_ty) ]

(* custom helpers: *)
let bool_to_int64 (b:bool): int64 = if b then 1L else 0L


let string_of_elt e =
  match e with
  | L l -> "\n" ^ l ^ ":"
  | I (u, i) -> "  " ^ u ^ " = " ^ Llutil.string_of_insn i
  | T t -> "  " ^ Llutil.string_of_terminator t
  | G (g, _) -> "GLOBAL: " ^ g
  | E (u, i) -> "ENTRY: " ^ u ^ " = " ^ Llutil.string_of_insn i

let print_stream (s:stream) =
  print_endline "--- STREAM ---";
  List.iter (fun e -> print_endline (string_of_elt e)) (List.rev s);
  print_endline "--------------"


(* Compiles an expression exp in context c, outputting the Ll operand that will
   recieve the value of the expression, and the stream of instructions
   implementing the expression. 

   Tips:
   - use the provided cmp_ty function!

   - string literals (CStr s) should be hoisted. You'll need to make sure
     either that the resulting gid has type (Ptr I8), or, if the gid has type
     [n x i8] (where n is the length of the string), convert the gid to a 
     (Ptr I8), e.g., by using getelementptr.

   - use the provided "oat_alloc_array" function to implement literal arrays
     (CArr) and the (NewArr) expressions

*)

let ast_bop_to_ll_bop (bop:Ast.binop) (ty:Ll.ty) (op1:Ll.operand) (op2:Ll.operand): Ll.insn =
  match bop with
  | Add -> Binop (Ll.Add, ty, op1, op2)
  | Sub -> Binop (Ll.Sub, ty, op1, op2)
  | Mul -> Binop (Ll.Mul, ty, op1, op2)
  | Shl -> Binop (Ll.Shl, ty, op1, op2)
  | Shr -> Binop (Ll.Lshr, ty, op1, op2)
  | Sar -> Binop (Ll.Ashr, ty, op1, op2)
  | IAnd | And -> Binop (Ll.And, ty, op1, op2) (* TODO: How to support bitwise and/or? *)
  | IOr | Or -> Binop (Ll.Or, ty, op1, op2)
  | Eq -> Icmp (Ll.Eq, ty, op1, op2)
  | Neq -> Icmp (Ll.Ne, ty, op1, op2)
  | Lt -> Icmp (Ll.Slt, ty, op1, op2)
  | Lte -> Icmp (Ll.Sle, ty, op1, op2)
  | Gt -> Icmp (Ll.Sgt, ty, op1, op2)
  | Gte -> Icmp (Ll.Sge, ty, op1, op2)

let rec get_arr_el_t (t:Ll.ty) : Ll.ty =
  match t with
  | Ll.Struct (_::[Ll.Array(_, typ)]) -> typ
  | Ll.Ptr (Ll.Struct (_::[Ll.Array(_, typ)])) -> typ
  | _ -> t

let rec cmp_exp (c:Ctxt.t) (exp:Ast.exp node) : Ll.ty * Ll.operand * stream =
  match exp.elt with
  | CNull n -> (cmp_rty n, Null, [])
  | CBool b -> (I1, Const (bool_to_int64 b), [])
  | CInt i -> (I64, Const i, [])
  | CStr s -> 
    (* watch out for hoisting use the G constructor! in the stream *)
     let str_gid = gensym "string_hoist" in
     let typ = Array ((String.length s) + 1, Ll.I8) in
     let str_ginit = GString s in
     let str_gdecl = (typ, str_ginit) in
     let str_ptr_id = gensym "str_ptr" in
     (* idea: use getelemptr to transform array into pointer to chars*)
     let gep_insn = Gep (Ptr typ, Gid str_gid, [Const 0L; Const 0L]) in
     (Ptr I8, Id str_ptr_id, [G (str_gid, str_gdecl); I (str_ptr_id, gep_insn)])
     (* (typ, Gid str_gid, [G (str_gid, str_gdecl)]) *)
     
  | CArr (ty, ls) -> 
    (* Allocate array and initialize with the given elements *)
    let n = List.length ls in
    let arr_ty, arr_op, alloc_strm = oat_alloc_array ty (Const (Int64.of_int n)) in
    (* Compile each element expression and store it in the array *)
    let element_ty = cmp_ty ty in
    let init_strm = List.mapi (fun i exp_node ->
      let exp_ty, exp_op, exp_strm = cmp_exp c exp_node in
      let ptr_id = gensym "arr_init_ptr" in
      let store_id = gensym "arr_init_store" in
      exp_strm 
      >@ [I (ptr_id, Gep (arr_ty, arr_op, [Const 0L; Const 1L; Const (Int64.of_int i)]))]
      >@ [I (store_id, Store (element_ty, exp_op, Id ptr_id))]
    ) ls |> List.fold_left (>@) [] in
    (arr_ty, arr_op, alloc_strm >@ init_strm)

  | NewArr (ty, exp) -> 
      let size_ty, size_op, size_strm = cmp_exp c exp in
      (* Allocate the array using the nice helper function *)
      let arr_ty, arr_op, alloc_strm = oat_alloc_array ty size_op in
      (arr_ty, arr_op, size_strm >@ alloc_strm)

  | Id id ->
    (* let ty, oprnd = Ctxt.lookup id c in
    (ty, oprnd, [])  *)
    (match Ctxt.lookup_option id c with
    | Some (ty, op) -> 
      (match ty with
      | Ptr (Ptr inner_ty) ->
        let load_uid = gensym "load_ref" in
        (Ptr inner_ty, Id load_uid, [I (load_uid, Load (ty, op))])
      | Ptr inner_ty ->
        let load_uid = gensym "load_val" in
        (inner_ty, Id load_uid, [I (load_uid, Load (ty, op))])
      | _ -> (ty, Id (gensym ("unqe"^id)), []) (* return as is with custom name*)
      )
    | None -> failwith "unbound variable ID"
      
    )

    (* let lk = Ctxt.lookup_option id c in
    (match lk with
    | Some (Ptr (Array (n, ty)), oprnd) ->
      (* Use Gep to load the actual array pointer *)
      let arr_ptr_id = gensym "array_ptr" in
      let gep_insn = Gep (Ptr (Array (n, ty)), oprnd, [Const 0L; Const 0L]) in
      (Ptr ty, Id arr_ptr_id, [I (arr_ptr_id, gep_insn)])
    | Some (Ptr ty, oprnd) ->
      let load_id = gensym "load_val" in
      (ty, Id load_id, [I (load_id, Load (Ptr ty, oprnd))])
    | _ -> failwith "Looked up invalid id: cmp_exp ID"
    ) *)

  | Index (exp1, exp2) -> 

    (* exp1[exp2] - compile as lhs then load *)
    let arr_t, arr_op, arr_strm = cmp_exp c exp1 in
    let idx_t, idx_op, idx_strm = cmp_exp c exp2 in
    (match (arr_t, idx_t) with
    | (Ptr (Struct [_; Array (_, element_ty)]), I64) -> 
      let ptr_id = gensym "index_ptr" in
      let load_id = gensym "index_load" in
      (element_ty, Id load_id,
        arr_strm 
        >@ idx_strm 
        >@ [I (ptr_id, Gep (arr_t, arr_op, [Const 0L; Const 1L; idx_op]))]
        >@ [I (load_id, Load (Ptr element_ty, Id ptr_id))]
      )
    | (Ptr (Ptr (Struct _)), I64) -> failwith "still weird?"
    | _ -> 
      print_stream arr_strm;
      print_stream idx_strm;
      failwith "This is weird"
    )
  (* | Index (e1, e2) ->
    let arr_t, arr_op, arr_strm = cmp_exp c e1 in 
    let arr_el_t = get_arr_el_t arr_t in
    let idx_t, idx_op, idx_strm = cmp_exp c e2 in 
    let id = gensym "gep" in 
    (* let id2 = gensym "load_gep" in *)
    (Ll.Ptr arr_el_t, Ll.Id id, arr_strm 
      >@ idx_strm 
      >@ [I (id, Ll.Gep (arr_t, arr_op, [Ll.Const 0L; Ll.Const 1L; idx_op]))]) *)

  (* | Index (exp1, exp2) -> 
    (* exp1[exp2] - compile as lhs then load *)
    let arr_t, arr_op, arr_strm = cmp_exp c exp1 in
    let idx_t, idx_op, idx_strm = cmp_exp c exp2 in
    (match (arr_t, idx_t) with
    | (Ptr (Struct [_; Array (_, element_ty)]), I64) -> 
      let ptr_id = gensym "index_ptr" in
      let load_id = gensym "index_load" in
      (element_ty, Id load_id,
        arr_strm 
        >@ idx_strm 
        >@ [I (ptr_id, Gep (arr_t, arr_op, [Const 0L; Const 1L; idx_op]))]
        >@ [I (load_id, Load (Ptr element_ty, Id ptr_id))]
      )
      (* handle global arrays; *)
    | (Struct [_; Array (_, element_ty)], I64) -> 
        let ptr_id = gensym "gindex_ptr" in
        let load_id = gensym "gindex_load" in
        (element_ty, Id load_id,
          arr_strm 
          >@ idx_strm
          >@ [ I (ptr_id, Gep (Ptr arr_t, arr_op, [Const 0L; Const 1L; idx_op])) ;
              I (load_id, Load (Ptr element_ty, Id ptr_id)) ]
        )
    | _ -> failwith "Index: expected array type and i64 index"
    ) *)
  (* | Index (exp1, exp2) -> 
    (* exp1[exp2] -> exp1 must be array, exp2 a number *)
    let arr_t, arr_op, arr_strm = cmp_exp c exp1 in
    let idx_t, idx_op, idx_strm = cmp_exp c exp2 in
    (match (arr_t, idx_t) with
    | (Ptr (Struct _), I64) -> 
      let Ptr (Struct types) = arr_t in 
      let arr_el_ty = List.hd types in
      let id = gensym "indexing" in
      (* Remember the GEP... first index over the pointer second index over the field:
        see: https://releases.llvm.org/21.1.0/docs/GetElementPtr.html
      *)
      (arr_el_ty, Id id,
       arr_strm 
       >@ idx_strm 
       (* TODO: FIX THIS GEP INSTRUCTION!!! *)
       >@ [I (id, Gep (arr_t, arr_op, [Const 0L; idx_op]))]
      )
    | _ -> failwith "Did not index an array with a number"
    ) *)


  | Call (exp, exp_ls) ->
    let func_t, func_op = Ctxt.lookup_function (match exp.elt with
      | Id id -> id
      | _ -> failwith "Function call must be an identifier - cmp_exp Call"
    ) c in
    (match func_t with
    | Ptr (Fun (arg_tys, ret_ty))
    | Fun (arg_tys, ret_ty) -> 
      let arg_ops_strms = List.map (cmp_exp c) exp_ls in
      let arg_ops = List.map (fun (_, op, _) -> op) arg_ops_strms in
      let arg_strms = List.fold_left (fun acc (_, _, strm) -> acc >@ strm) [] arg_ops_strms in
      let call_id = gensym "call" in
      (ret_ty, Id call_id,
       arg_strms
       >@ [I (call_id, Call (ret_ty, func_op, List.combine arg_tys arg_ops))])
    | _ -> failwith "Called a non-function - cmp_exp Call"
    )

  | Bop (bop, exp1, exp2) -> 
    let expt1, op1, strm1 = cmp_exp c exp1 in
    let expt2, op2, strm2 = cmp_exp c exp2 in
    (* if expt1 <> expt2 then failwith "Invalid Binary Operation: Operands do not match - cmp_exp Bop" *)
    let id = gensym "binop" in
    let typ_ = typ_of_binop bop in
    let typ = (match typ_ with
    | (TInt, TInt, TInt) -> I64
    | (TInt, TInt, TBool) -> I1
    | (TBool, TBool, TBool) -> I1
    | _ -> failwith "You are a magician - Bop - cmp_exp"
    ) in
    let ret_strm = strm1 >@ strm2 >@ [I (id, ast_bop_to_ll_bop bop expt1 op1 op2)] in
  
    (typ, Id id, ret_strm)


  | Uop (op, exp) -> 
    let typ, opnd, strm = cmp_exp c exp in
    let id = gensym "uop" in
    let ret_strm = [I (id, 
      match op with
      | Neg -> Binop (Ll.Sub, I64, Const 0L, opnd)
      | Lognot -> Icmp (Ll.Eq, I1, opnd, Const 0L)
      | Bitnot -> Binop (Ll.Xor, I64, opnd, Const (-1L))
    )] in
    (typ, Id id, strm >@ ret_strm)
    

(* Compile a statement in context c with return typ rt. Return a new context, 
   possibly extended with new local bindings, and the instruction stream
   implementing the statement.

   Left-hand-sides of assignment statements must either be OAT identifiers,
   or an index into some arbitrary expression of array type. Otherwise, the
   program is not well-formed and your compiler may throw an error.

   Tips:
   - for local variable declarations, you will need to emit Allocas in the
     entry block of the current function using the E() constructor.

   - don't forget to add a bindings to the context for local variable 
     declarations
   
   - you can avoid some work by translating For loops to the corresponding
     While loop, building the AST and recursively calling cmp_stmt

   - you might find it helpful to reuse the code you wrote for the Call
     expression to implement the SCall statement

   - compiling the left-hand-side of an assignment is almost exactly like
     compiling the Id or Index expression. Instead of loading the resulting
     pointer, you just need to store to it!

 *)

let cmp_lhs (c:Ctxt.t) (id:Ast.id) : Ll.ty * Ll.operand * stream =
  let lk = Ctxt.lookup_option id c in
  match lk  with
  | Some (ty, op) -> (ty, op, [])
  | None -> failwith ("unbound variable in assignment: " ^ id)

let rec cmp_stmt (c:Ctxt.t) (rt:Ll.ty) (stmt:Ast.stmt node) : Ctxt.t * stream =
  match stmt.elt with
  | Ret Some(exp_node) ->
    let ty, oprnd, strm = cmp_exp c exp_node in
    (* TODO: handle edge cases!!*)
    if ty = rt then (c, strm >@ [T (Ret (ty, Some (oprnd)))])

    else if ty = Ptr rt then
        let id = gensym "loaded" in
        ( c, strm 
             >@ [I (id, Load (Ptr rt, oprnd))] 
             >@ [T (Ret (rt, Some (Id id)))]
        )
    else failwith "Other cases in Return some value"
    
  | Ret _ -> 
    (match rt with
    | Void -> (c, [T (Ret (Void, None))])
    | _ -> failwith "Must return void for None return - cmp_stmt"
    )
  | Decl (id, exp_node) ->
    let ty, oprnd, strm = cmp_exp c exp_node in
    let unique_id = gensym id in
    (* Do not forget to add the binding to the context!! *)
    let c' = Ctxt.add c id (Ptr ty, Id unique_id) in (* shadowing the global same name values*)
    (c', strm >@ [E (unique_id, Ll.Alloca ty)] 
              >@ [I (unique_id, Ll.Store (ty, oprnd, Id unique_id))])
  | While (exp_node, body) ->
    (* This is a scoping statement, which means that the context needs to be 
       saved before executing the body of the loop*)
    let ty, cond_oprnd, cond_strm = cmp_exp c exp_node in
    (match ty with
    | I1 -> 
            let context_before = c in
            let c', body_strm = cmp_block c rt body in
            (* See slides lecture 14 for reference *)
            let l_before_loop = gensym "lpre" in
            let l_loop_body = gensym "lbody" in
            let l_after_loop = gensym "lpost" in
            let while_stream = 
              [T (Br l_before_loop)]
              >@ [L (l_before_loop)] 
              >@ cond_strm
              (* TODO: potentially swap order of labels... slides have them reversed *)
              >@ [T (Cbr (cond_oprnd, l_loop_body, l_after_loop))]
              >@ [L (l_loop_body)]
              >@ body_strm
              >@ [T (Br l_before_loop)]
              >@ [L (l_after_loop)] 
            in
            (context_before, while_stream)
    | _ -> failwith "Cond not a boolean"
    )

  | For (vdecls, cond_opt, update_opt, body) ->
    (* Again, this is a scoping statement, save the outer context *)
    let context_before = c in
    let c', init_strm = List.fold_left (fun (c_acc, strm_acc) var_dec -> 
                                        let vdecl = no_loc (Ast.Decl var_dec) in
                                        let c_new, decl_strm = cmp_stmt c_acc rt vdecl in
                                        (c_new, strm_acc >@ decl_strm)
                                      ) (c, []) vdecls in
    let update_strm = (match update_opt with
                      | Some(update) -> let _, s = cmp_stmt c' rt update in s
                      | _ -> []) in
    let cond_ty, cond_oprnd, cond_strm = (match (cond_opt) with
                                         | Some(cond) -> cmp_exp c' cond (* while cond {body; update}*)
                                         | _ -> cmp_exp c' (no_loc (CBool true))  (* no condition = while true *)
                                         ) in 
    let c'', body_strm = cmp_block c' rt body in
    (* Idea: use cmp_stmt while in order to write less *)
    let l_pre = gensym "lpre" in
    let l_body = gensym "lbody" in
    let l_post = gensym "lpost" in
    let while_stream = 
      [T (Br (l_pre))]
      >@ [L (l_pre)] 
      >@ (cond_strm) 
      >@ [T (Cbr (cond_oprnd, l_body, l_post))]
      >@ [L (l_body)] 
      >@ body_strm 
      >@ update_strm 
      >@ [T (Br (l_pre))]
      >@ [L (l_post)]
    in
    (context_before, init_strm >@ while_stream)
    (* Finished body is: init_stream; while (cond_strem) {body ;update_stream} *)

    (* Idea: translate for (init; cond; update) { body } into
        init;
        while (cond) { body }
    *)
  | If (cond, then_branch, else_branch) -> 
    let cond_ty, cond_oprnd, cond_strm = cmp_exp c cond in
    (match cond_ty with
    | I1 -> 
        let c_then, then_strm = cmp_block c rt then_branch in
        let c_else, else_strm = cmp_block c rt else_branch in
        let l_then = gensym "lthen" in
        let l_else = gensym "lelse" in
        let l_after = gensym "lafter" in
        let if_stream = cond_strm 
                        >@ [T (Cbr (cond_oprnd, l_then, l_else))]
                        >@ [L (l_then)]
                        >@ then_strm 
                        >@ [T (Br l_after)]
                        >@ [L (l_else)] 
                        >@ else_strm 
                        >@ [T (Br l_after)]
                        >@ [L (l_after)] 
        in
        (c, if_stream)
    | _ -> failwith "Condition not a boolean: If - cmp_stmt"
    )
  | Assn (lhs, rhs) ->
     (* rememer the two types of assignments: x = 1 and x[0] = 42 *)
     (match lhs.elt with
      | Id id ->
        (match (Ctxt.lookup_option id c) with 
        | Some (Ptr stored_ty, ptr_op) -> (* stored_ty is the type pointed to by ptr_op *)
            let rhs_ty, rhs_oprnd, rhs_strm = cmp_exp c rhs in
              if rhs_ty = stored_ty then
                  let store_insn = Store (rhs_ty, rhs_oprnd, ptr_op) in
                  (c, rhs_strm >@ [I (gensym "store", store_insn)])
              else
                  failwith "Assignment type mismatch: RHS value type does not match LHS storage type"
                
        | Some _ -> failwith "Assign to non-pointer!!"
        | _ -> failwith ("Unbound id in assignment: " ^ id)
        )
        (* (match (Ctxt.lookup_option id c) with 
        | Some (Ptr lhs_ty, ptr_op) ->
          let rhs_ty, rhs_oprnd, rhs_strm = cmp_exp c rhs in
          let assign_id = gensym "assign" in
          (c, rhs_strm >@ [I (assign_id, Store (rhs_ty, rhs_oprnd, ptr_op))])
        | Some _ -> failwith "Assign to non pointer!!"
        | _ -> failwith ("Unbound id in assignment: " ^ id)
        ) *)
      | Index (exp1, exp2) -> (* Case: x[0] = 42 *)
          (* Compile the array and index *)
       let arr_t, arr_op, arr_strm = cmp_exp c exp1 in
       let idx_t, idx_op, idx_strm = cmp_exp c exp2 in
       let rhs_ty, rhs_op, rhs_strm = cmp_exp c rhs in
       (match arr_t with
       | Ptr (Struct [_; Array (_, element_ty)]) ->
         let ptr_id = gensym "assign_ptr" in
         let store_id = gensym "assign_store" in
         (c, arr_strm 
             >@ idx_strm 
             >@ rhs_strm
             >@ [I (ptr_id, Gep (arr_t, arr_op, [Const 0L; Const 1L; idx_op]))]
             >@ [I (store_id, Store (element_ty, rhs_op, Id ptr_id))])
       | _ -> failwith "Assignment to non-array index"
       )
      | _ -> failwith "Invalid left-hand-side in assignment"
      )
 
  | SCall (exp_node, exp_node_list) -> 
    (* Idea: resuse most of the Call exp to handle the SCall statement: *)
    let func_t, func_op = Ctxt.lookup_function (match exp_node.elt with
      | Id id -> id
      | _ -> failwith "Function call must be an identifier - cmp_exp Call"
    ) c in
    (match func_t with
    | Ptr (Fun (arg_tys, ret_ty))
    | Fun (arg_tys, ret_ty) -> 
      let arg_ops_strms = List.map (cmp_exp c) exp_node_list in
      let arg_ops = List.map (fun (_, op, _) -> op) arg_ops_strms in
      let arg_strms = List.fold_left (fun acc (_, _, strm) -> acc >@ strm) [] arg_ops_strms in
      let call_id = gensym "scall" in
      (c,
       arg_strms
       >@ [I (call_id, Call (ret_ty, func_op, List.combine arg_tys arg_ops))])
    | _ -> failwith "Called a non-function - cmp_exp Call"
    )

    

(* Compile a series of statements *)
and cmp_block (c:Ctxt.t) (rt:Ll.ty) (stmts:Ast.block) : Ctxt.t * stream =
  List.fold_left (fun (c, code) s -> 
      let c, stmt_code = cmp_stmt c rt s in
      c, code >@ stmt_code
    ) (c,[]) stmts



(* Adds each function identifer to the context at an
   appropriately translated type.  

   NOTE: The Gid of a function is just its source name
*)
let cmp_function_ctxt (c:Ctxt.t) (p:Ast.prog) : Ctxt.t =
    List.fold_left (fun c -> function
      | Ast.Gfdecl { elt={ frtyp; fname; args } } ->
         let ft = TRef (RFun (List.map fst args, frtyp)) in
         Ctxt.add c fname (cmp_ty ft, Gid fname)
      | _ -> c
    ) c p 



(* Get the LL type of an Ast.exp  *)
let rec typ_of_glbl_expr (a:Ast.exp): Ll.ty =
  match a with
  | CNull t -> cmp_ty (TRef t)  (* FIX: Use cmp_ty to get Ptr *)
  | CBool _ -> I1
  | CInt _  -> I64
  | CStr s  -> Ptr I8
  | CArr (ty, elts) -> cmp_ty (TRef (RArray ty))
  | _ -> failwith "typ_of_glbl_expr: unsupported global initializer"

(* Populate a context with bindings for global variables 
   mapping OAT identifiers to LLVMlite gids and their types.

   Only a small subset of OAT expressions can be used as global initializers
   in well-formed programs. (The constructors starting with C). 
*)
let cmp_global_ctxt (c:Ctxt.t) (p:Ast.prog) : Ctxt.t =

  List.fold_left (fun c -> function
    | Gvdecl g -> 
      let id = g.elt.name in
      let typ: Ll.ty = typ_of_glbl_expr g.elt.init.elt  in
      (* bind the value - note: globals are stored as pointers to their values *)
      let bnd = (Ptr typ, Ll.Gid id) in
      (* Add every id and binding to the context*)
      Ctxt.add c id bnd
    | _ -> c
  ) c p

(* Compile a function declaration in global context c. Return the LLVMlite cfg
   and a list of global declarations containing the string literals appearing
   in the function.

   You will need to
   1. Allocate stack space for the function parameters using Alloca
   2. Store the function arguments in their corresponding alloca'd stack slot
   3. Extend the context with bindings for function variables
   4. Compile the body of the function using cmp_block
   5. Use cfg_of_stream to produce a LLVMlite cfg from 
 *)

let generate_function_code (f_types: Ll.fty) (f_params: Ll.uid list) (code: stream) (c:Ctxt.t): (Ctxt.t * stream) = 
  let arg_tys = fst f_types in
  List.fold_left2 (fun (c_acc, strm_acc) f_type f_param -> 
        let uid = gensym "func_uid" in
        let store_uid = gensym "store_param" in
        let new_ctxt = Ctxt.add c_acc f_param (Ptr f_type, Id uid) in
        let new_strm = strm_acc >@ [E (uid, Alloca f_type)] >@ [I (store_uid, Store (f_type, Id f_param, Id uid))] in
        (new_ctxt, new_strm)
  ) (c, code) arg_tys f_params


let cmp_fdecl (c:Ctxt.t) (f:Ast.fdecl node) : Ll.fdecl * (Ll.gid * Ll.gdecl) list =
  (* given a context and an AST function declaration, return a 
     LL function declaration and a list of (gid, gdecl)
  *)
  (* Do NOT forget to do the 5 steps above!!! *)

  let func = f.elt in
  let function_return_type: Ast.ret_ty = func.frtyp in
  let function_name: Ast.id = func.fname in
  let function_args: (Ast.ty * Ast.id) list = func.args in
  let function_body: Ast.block = func.body in
  let ll_frty = cmp_ret_ty function_return_type in

  let ll_fty: Ll.fty = (List.map cmp_ty (List.map fst function_args), cmp_ret_ty function_return_type) in
  let ll_f_param: Ll.uid list = List.map snd function_args in

  let c_fresh = c in 


  let c_with_params, init_stream = generate_function_code ll_fty ll_f_param [] c_fresh (* generate code and doing the 5 steps above!! *) in
  let c_body, ll_body = cmp_block c_with_params (ll_frty) function_body in
  let full_stream = init_stream >@ ll_body in
                     (* >@ (match cmp_ret_ty function_return_type with
                        | Void -> [T (Ret (Void, None))]
                        | _ -> [])  in *)
  (* print_stream full_stream; *)
  let cfg, some_list = cfg_of_stream full_stream in
  (* Printf.printf "Function %s compiled to CFG %s\n" function_name (Llutil.string_of_cfg cfg);
  print_endline "--------------END CFG ----------------"; *)
  (* create a cfg by building a stream and  using cfg_of_stream *)

    (* Note: lift takes a Ll.block.insns and returns a stream.*)
    (* 
      Idea: transform function body into a list of elt and 
      then use cfg_of_stream to convert it into a Ll.cfg
    *)

    (* let entry_label = gensym "entry" in
    let entry_block = L entry_label >:: lift (
      List.mapi (fun i (arg_ty, arg_id) ->
        let param_id = List.nth ll_f_param i in
        let alloca_id = gensym ("alloca_" ^ arg_id) in
        (* Allocate space for the parameter *)
        let alloca_insn = Alloca arg_ty in
        (* Store the parameter into the allocated space *)
        let store_insn = Store (arg_ty, Id param_id, Id alloca_id) in
        (* Add binding to context *)
        let c = Ctxt.add c arg_id (arg_ty, Id alloca_id) in
        (alloca_id, alloca_insn), ((), store_insn), c
      ) function_args |> List.flatten |> List.split3 |> fun (allocas, stores, contexts) ->
      let c' = List.fold_left (fun acc ctx -> ctx) c contexts in
      let store_stream = lift stores in
      let alloc_stream = lift allocas in
      let body_c, body_stream = cmp_block c' (cmp_ret_ty function_return_type) function_body in
      let full_stream = entry_block >@ alloc_stream >@ store_stream >@ body_stream in
      cfg_of_stream full_stream
    )  *)
  
  let ll_fdecl = { f_ty=ll_fty; f_param=ll_f_param; f_cfg=cfg } in
  (* compute the list of gids to gdecls *)
    (ll_fdecl, some_list)




(* Compile a global initializer, returning the resulting LLVMlite global
   declaration, and a list of additional global declarations.

   Tips:
   - Only CNull, CBool, CInt, CStr, and CArr can appear as global initializers
     in well-formed OAT programs. Your compiler may throw an error for the other
     cases

   - OAT arrays are always handled via pointers. A global array of arrays will
     be an array of pointers to arrays emitted as additional global declarations.
*)
(* Compile a global initializer *)
let rec cmp_gexp c (e:Ast.exp node) : Ll.gdecl * (Ll.gid * Ll.gdecl) list =
  begin match e.elt with
    | CInt i -> (I64, GInt i), []
    | CBool b -> (I1, GInt (if b then 1L else 0L)), []
    | CNull r -> (cmp_ty (TRef r), GNull), []
    | CStr s -> 
      let data_gid = gensym "str_data" in
      let data_ty = Array(String.length s + 1, I8) in
      let ptr_ty = Ptr I8 in
      let cast_init = GBitcast (Ptr data_ty, GGid data_gid, ptr_ty) in
      (ptr_ty, cast_init), [data_gid, (data_ty, GString s)]

    | CArr (ty, elem_exps) ->
      (* 1. Helper types *)
      let ll_val_ty = cmp_ty (TRef (RArray ty)) in (* Generic Oat Array Type: {i64, [0 x T]}* *)
      let elem_ll_ty = cmp_ty ty in
      let elem_count = List.length elem_exps in
      
      (* 2. Define the specific data type: {i64, [N x T]} *)
      let data_struct_ty = Struct [I64; Array(elem_count, elem_ll_ty)] in

      (* 3. Recursively compile elements (they might be strings requiring hoisting) *)
      let compiled_elems = List.map (fun x -> cmp_gexp c x) elem_exps in
      let g_inits = List.map (fun ((_, g), _) -> g) compiled_elems in
      let extra_gdecls = List.concat (List.map snd compiled_elems) in
      
      (* 4. Create the hidden global for the array data *)
      let data_gid = gensym "garr_data" in
      let struct_gdecl = (
        data_struct_ty, 
        GStruct [
          (I64, GInt (Int64.of_int elem_count)); 
          (Array(elem_count, elem_ll_ty), GArray (List.map (fun g -> (elem_ll_ty, g)) g_inits))
        ]
      ) in
      
      (* 5. The main global is a Bitcast pointer to the hidden data *)
      let cast_init = GBitcast (Ptr data_struct_ty, GGid data_gid, ll_val_ty) in
      
      (* Return the main global init, plus the hidden global and any others *)
      ((ll_val_ty, cast_init), (data_gid, struct_gdecl) :: extra_gdecls)

    | _ -> failwith "Invalid expression for global initializer"
end
(* let rec cmp_gexp c (e:Ast.exp node) : Ll.gdecl * (Ll.gid * Ll.gdecl) list =
  let exp = e.elt in
  (* Why only certain types require additional gid info:
      - CStr: need to emit the string literal as a global array of i8
      - CArr: need to emit each element as a separate global if they are
        reference types (pointers)
  *)
  (match exp with
  | CNull n -> ((Ptr (cmp_rty n), GNull), [])
  | CBool b -> ((I1, GInt (bool_to_int64 b)), [])
  | CInt i -> ((I64, GInt i), [])
  (* Knowing that Oat strings are pointers to byte, translate them to 
     LLVMlite where a string is an array of chars *)
  | CStr s -> 
      let gid = gensym "global_str" in
      let str_ty = Array (String.length s + 1, I8) in
      let gdecl = (str_ty, GString s) in
      (* TODO: Do I need to bitcast already? *)
      ((Ptr I8, GBitcast (Ptr str_ty, GGid gid, Ptr I8)), [(gid, gdecl)])
  | CArr (ty, expressions) -> 

    (* OAT arrays are always handled via pointers. A global array of arrays will
     be an array of pointers to arrays emitted as additional global declarations. *)
    
     (* Global initialized arrays are allocated at compile time, 
     while those local to a function must be allocated at run time, on the heap *)

    let n = List.length expressions in
    (* The plan: initialize an empty array of type ty and then populate it with 
     the constants found in the expressions list*)
    let element_ty = cmp_ty ty in
    let array_ty = Struct [I64; Array (n, element_ty)] in
    (* How do I initialize a constant array at compile time? *)
    (* compare to globals4.oat:
    global arr = new int[]{1, 2, 3, 4};
    int program(int argc, string[] args) {
      return 5;
    }
        *)
        (* Like this: *)
    (* let ginit = GStruct ([  (I64, GInt (Int64.of_int n));
                            (Array (n, element_ty),
                             GArray [(I64, GInt 1L);
                                     (I64, GInt 2L);
                                     (I64, GInt 3L);
                                     (I64, GInt 4L);
                                    ]
                            )
                          ]) in *)
    let arr_decl = (I64, GInt (Int64.of_int n)) in
    let arr_list = List.map (fun exp_node ->
                        let gdecl, additional_gdecls = cmp_gexp c exp_node in
                        match gdecl with
                        | (ty, ginit) -> ginit
                      ) expressions in
    let type_list = List.map (fun exp -> element_ty) expressions in
    let arr_elems = (Array (n, element_ty), GArray (List.combine type_list arr_list)) in
    let ginit = GStruct ([arr_decl; arr_elems]) in
    (* let ginit = GStruct ([ (I64, GInt (Int64.of_int n)) ] @
                          List.map ()  *)
    let gdecl = (array_ty, ginit) in
    (gdecl, [])
    (* (gdecl, (gid, gdecl) :: additional_gdecls)   *)


  | _ -> failwith "cmp_gexp: unsupported global initializer"
  )

 *)
(* Oat internals function context ------------------------------------------- *)
let internals = [
    "oat_alloc_array",         Ll.Fun ([I64], Ptr I64)
  ]

(* Oat builtin function context --------------------------------------------- *)
let builtins =
  [ "array_of_string",  cmp_rty @@ RFun ([TRef RString], RetVal (TRef(RArray TInt)))
  ; "string_of_array",  cmp_rty @@ RFun ([TRef(RArray TInt)], RetVal (TRef RString))
  ; "length_of_string", cmp_rty @@ RFun ([TRef RString],  RetVal TInt)
  ; "string_of_int",    cmp_rty @@ RFun ([TInt],  RetVal (TRef RString))
  ; "string_cat",       cmp_rty @@ RFun ([TRef RString; TRef RString], RetVal (TRef RString))
  ; "print_string",     cmp_rty @@ RFun ([TRef RString],  RetVoid)
  ; "print_int",        cmp_rty @@ RFun ([TInt],  RetVoid)
  ; "print_bool",       cmp_rty @@ RFun ([TBool], RetVoid)
  ]

(* Compile a OAT program to LLVMlite *)
let cmp_prog (p:Ast.prog) : Ll.prog =
  (* add built-in functions to context *)
  let init_ctxt = 
    List.fold_left (fun c (i, t) -> Ctxt.add c i (Ll.Ptr t, Gid i))
      Ctxt.empty builtins
  in
  let fc = cmp_function_ctxt init_ctxt p in

  (* build global variable context *)
  let c = cmp_global_ctxt fc p in

  (* compile functions and global variables *)
  let fdecls, gdecls = 
    List.fold_right (fun d (fs, gs) ->
        match d with
        | Ast.Gvdecl { elt=gd } -> 
           let ll_gd, gs' = cmp_gexp c gd.init in
           (fs, (gd.name, ll_gd)::gs' @ gs)
        | Ast.Gfdecl fd ->
           let fdecl, gs' = cmp_fdecl c fd in
           (fd.elt.fname,fdecl)::fs, gs' @ gs
      ) p ([], [])
  in

  (* gather external declarations *)
  let edecls = internals @ builtins in
  { tdecls = []; gdecls; fdecls; edecls }